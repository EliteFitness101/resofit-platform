import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { storefrontApiRequest, type ShopifyProduct } from "@/lib/shopify";

export interface CartItem {
  lineId: string | null;
  product: ShopifyProduct;
  variantId: string;
  variantTitle: string;
  price: { amount: string; currencyCode: string };
  quantity: number;
  selectedOptions: Array<{ name: string; value: string }>;
}

interface CartStore {
  items: CartItem[];
  cartId: string | null;
  checkoutUrl: string | null;
  isLoading: boolean;
  isSyncing: boolean;
  addItem: (item: Omit<CartItem, "lineId">) => Promise<void>;
  updateQuantity: (variantId: string, quantity: number) => Promise<void>;
  removeItem: (variantId: string) => Promise<void>;
  clearCart: () => void;
  syncCart: () => Promise<void>;
  getCheckoutUrl: () => string | null;
}

const CART_QUERY = `query cart($id: ID!) { cart(id: $id) { id totalQuantity } }`;

const CART_CREATE = `
  mutation cartCreate($input: CartInput!) {
    cartCreate(input: $input) {
      cart { id checkoutUrl lines(first: 100) { edges { node { id merchandise { ... on ProductVariant { id } } } } } }
      userErrors { field message }
    }
  }`;

const CART_LINES_ADD = `
  mutation cartLinesAdd($cartId: ID!, $lines: [CartLineInput!]!) {
    cartLinesAdd(cartId: $cartId, lines: $lines) {
      cart { id lines(first: 100) { edges { node { id merchandise { ... on ProductVariant { id } } } } } }
      userErrors { field message }
    }
  }`;

const CART_LINES_UPDATE = `
  mutation cartLinesUpdate($cartId: ID!, $lines: [CartLineUpdateInput!]!) {
    cartLinesUpdate(cartId: $cartId, lines: $lines) { cart { id } userErrors { field message } }
  }`;

const CART_LINES_REMOVE = `
  mutation cartLinesRemove($cartId: ID!, $lineIds: [ID!]!) {
    cartLinesRemove(cartId: $cartId, lineIds: $lineIds) { cart { id } userErrors { field message } }
  }`;

function formatCheckoutUrl(url: string) {
  try {
    const u = new URL(url);
    u.searchParams.set("channel", "online_store");
    return u.toString();
  } catch {
    return url;
  }
}

function isCartNotFound(errs: Array<{ message: string }>) {
  return errs.some((e) => {
    const m = e.message.toLowerCase();
    return m.includes("cart not found") || m.includes("does not exist");
  });
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      cartId: null,
      checkoutUrl: null,
      isLoading: false,
      isSyncing: false,

      addItem: async (item) => {
        const { items, cartId, clearCart } = get();
        const existing = items.find((i) => i.variantId === item.variantId);
        set({ isLoading: true });
        try {
          if (!cartId) {
            const data = await storefrontApiRequest(CART_CREATE, {
              input: { lines: [{ quantity: item.quantity, merchandiseId: item.variantId }] },
            });
            const errs = data?.data?.cartCreate?.userErrors || [];
            if (errs.length) return;
            const cart = data?.data?.cartCreate?.cart;
            if (!cart?.checkoutUrl) return;
            const lineId = cart.lines.edges[0]?.node?.id;
            set({
              cartId: cart.id,
              checkoutUrl: formatCheckoutUrl(cart.checkoutUrl),
              items: [{ ...item, lineId: lineId ?? null }],
            });
          } else if (existing) {
            if (!existing.lineId) return;
            const newQty = existing.quantity + item.quantity;
            const data = await storefrontApiRequest(CART_LINES_UPDATE, {
              cartId,
              lines: [{ id: existing.lineId, quantity: newQty }],
            });
            const errs = data?.data?.cartLinesUpdate?.userErrors || [];
            if (isCartNotFound(errs)) return clearCart();
            if (errs.length) return;
            set({ items: get().items.map((i) => (i.variantId === item.variantId ? { ...i, quantity: newQty } : i)) });
          } else {
            const data = await storefrontApiRequest(CART_LINES_ADD, {
              cartId,
              lines: [{ quantity: item.quantity, merchandiseId: item.variantId }],
            });
            const errs = data?.data?.cartLinesAdd?.userErrors || [];
            if (isCartNotFound(errs)) return clearCart();
            if (errs.length) return;
            const lines = data?.data?.cartLinesAdd?.cart?.lines?.edges || [];
            const newLine = lines.find(
              (l: { node: { merchandise: { id: string } } }) => l.node.merchandise.id === item.variantId,
            );
            set({ items: [...get().items, { ...item, lineId: newLine?.node?.id ?? null }] });
          }
        } catch (e) {
          console.error("addItem failed", e);
        } finally {
          set({ isLoading: false });
        }
      },

      updateQuantity: async (variantId, quantity) => {
        if (quantity <= 0) return get().removeItem(variantId);
        const { items, cartId, clearCart } = get();
        const item = items.find((i) => i.variantId === variantId);
        if (!item?.lineId || !cartId) return;
        set({ isLoading: true });
        try {
          const data = await storefrontApiRequest(CART_LINES_UPDATE, {
            cartId,
            lines: [{ id: item.lineId, quantity }],
          });
          const errs = data?.data?.cartLinesUpdate?.userErrors || [];
          if (isCartNotFound(errs)) return clearCart();
          if (errs.length) return;
          set({ items: get().items.map((i) => (i.variantId === variantId ? { ...i, quantity } : i)) });
        } finally {
          set({ isLoading: false });
        }
      },

      removeItem: async (variantId) => {
        const { items, cartId, clearCart } = get();
        const item = items.find((i) => i.variantId === variantId);
        if (!item?.lineId || !cartId) return;
        set({ isLoading: true });
        try {
          const data = await storefrontApiRequest(CART_LINES_REMOVE, { cartId, lineIds: [item.lineId] });
          const errs = data?.data?.cartLinesRemove?.userErrors || [];
          if (isCartNotFound(errs)) return clearCart();
          if (errs.length) return;
          const next = get().items.filter((i) => i.variantId !== variantId);
          next.length === 0 ? clearCart() : set({ items: next });
        } finally {
          set({ isLoading: false });
        }
      },

      clearCart: () => set({ items: [], cartId: null, checkoutUrl: null }),
      getCheckoutUrl: () => get().checkoutUrl,

      syncCart: async () => {
        const { cartId, isSyncing, clearCart } = get();
        if (!cartId || isSyncing) return;
        set({ isSyncing: true });
        try {
          const data = await storefrontApiRequest(CART_QUERY, { id: cartId });
          if (!data) return;
          const cart = data?.data?.cart;
          if (!cart || cart.totalQuantity === 0) clearCart();
        } catch (e) {
          console.error("syncCart failed", e);
        } finally {
          set({ isSyncing: false });
        }
      },
    }),
    {
      name: "shopify-cart",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({ items: s.items, cartId: s.cartId, checkoutUrl: s.checkoutUrl }),
    },
  ),
);
