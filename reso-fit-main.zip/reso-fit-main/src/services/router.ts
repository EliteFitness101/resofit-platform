// Lightweight client-side router for the ResoFit ecosystem.
// Single source of truth for outbound URLs.

export const ECOSYSTEM = {
  checkout: "https://joy-funnel-ai.lovable.app",
  evolution: "https://resofit-evolution.lovable.app",
  goldFlow: "https://sovereign-gold-flow.lovable.app",
  dashboard: "https://reso-flex-pwa.lovable.app/macros",
  elite: "https://elite-products.lovable.app",
  naijaStore: "https://naija-elite-forge.lovable.app/store",
  reset: "https://resofit-reset.lovable.app",
  glow: "https://resofit-glow-launch.lovable.app",
  resogold: "https://resogold.lovable.app",
  nownowgym: "https://nownowgym.lovable.app",
  supplement: "https://resofit-reset.lovable.app/product/resoflex-reset",
  auth: "https://candera.lovable.app/auth",
  vault: "https://luxury-wellness-ai--resofit.replit.app/vault",
  whatsapp: "https://wa.me/2348132255842?text=I%20want%20to%20join%20ResoFit",
  tiktok: "https://www.tiktok.com/@resoflex2",
  tiktokAlt: "https://www.tiktok.com/@resonancefitness",
} as const;

export const CONTACT = {
  whatsapp: "+2348132255842",
  emails: {
    general: "resoflex@resoflex.name.ng",
    payment: "payment@resofit.fit",
    recruit: "recruit@resofit.fit",
    support: "support@resofit.fit",
    invest: "invest@resoflex.name.ng",
  },
} as const;

export type Intent = "checkout" | "vip" | "dashboard" | "evolution" | "store" | "auth";

const KEY_RETURNING = "resofit:returning";

// NOTE: We intentionally do NOT track payment state on this origin.
// Payment verification and gated access are enforced by the destination
// apps (joy-funnel-ai for checkout, reso-flex-pwa for the dashboard).
// A client-readable "paid" flag would be trivially forged via devtools,
// so routing here is based only on user intent + a non-sensitive
// "returning visitor" hint.
export const flags = {
  isReturning: () => typeof window !== "undefined" && localStorage.getItem(KEY_RETURNING) === "1",
  markReturning: () => {
    if (typeof window !== "undefined") localStorage.setItem(KEY_RETURNING, "1");
  },
};

export function resolveDestination(intent?: Intent | string | null): string {
  switch (intent) {
    case "checkout": return ECOSYSTEM.checkout;
    case "vip": return ECOSYSTEM.elite;
    case "dashboard": return ECOSYSTEM.dashboard;
    case "evolution": return ECOSYSTEM.evolution;
    case "store": return ECOSYSTEM.naijaStore;
    case "auth": return ECOSYSTEM.auth;
    default:
      return flags.isReturning() ? ECOSYSTEM.evolution : ECOSYSTEM.checkout;
  }
}
