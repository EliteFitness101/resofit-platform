import { useState } from "react";
import { Crown, Sparkles, ShoppingBag, Layers, Flame, X, ExternalLink } from "lucide-react";

type Bubble = {
  id: string;
  label: string;
  url: string;
  icon: typeof Crown;
  accent: string;
};

const BUBBLES: Bubble[] = [
  {
    id: "luxury-saas",
    label: "Luxury SaaS",
    url: "https://v0.app/chat/luxury-saas-dashboard-kxZCx9mXi9h",
    icon: Crown,
    accent: "from-amber-400 to-yellow-600",
  },
  {
    id: "sovereign",
    label: "Sovereign ResoFit",
    url: "https://sovereign-resofit.lovable.app",
    icon: Sparkles,
    accent: "from-fuchsia-500 to-purple-700",
  },
  {
    id: "reset-shop",
    label: "Reset Shop",
    url: "https://resofit-reset.lovable.app/shop",
    icon: ShoppingBag,
    accent: "from-emerald-400 to-teal-600",
  },
  {
    id: "vm-preview",
    label: "VM Preview",
    url: "https://vm-85nmslelru33ip9wc9u920ko.vusercontent.net",
    icon: Layers,
    accent: "from-sky-400 to-indigo-600",
  },
  {
    id: "7day",
    label: "7-Day Reset",
    url: "https://reset.resofit.fit/7day",
    icon: Flame,
    accent: "from-orange-500 to-rose-600",
  },
];

export function PremiumBubbles() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<Bubble | null>(null);

  return (
    <>
      <div className="fixed left-4 bottom-20 z-40 flex flex-col items-start gap-2 md:bottom-6">
        {open &&
          BUBBLES.map((b) => {
            const Icon = b.icon;
            return (
              <button
                key={b.id}
                onClick={() => setActive(b)}
                className={`group flex items-center gap-2 rounded-full bg-gradient-to-r ${b.accent} px-3 py-2 text-xs font-semibold text-white shadow-lg transition-transform hover:scale-105`}
                aria-label={`Open ${b.label}`}
              >
                <Icon className="h-4 w-4" />
                <span className="whitespace-nowrap">{b.label}</span>
              </button>
            );
          })}
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary to-amber-600 text-primary-foreground shadow-gold transition-transform hover:scale-110"
          aria-label="Premium experiences"
          aria-expanded={open}
        >
          {open ? <X className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
        </button>
      </div>

      {active && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-2 backdrop-blur-sm md:p-6"
          onClick={() => setActive(null)}
        >
          <div
            className="relative flex h-full w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-border/60 bg-background shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-border/60 bg-background/95 px-4 py-2">
              <div className="flex items-center gap-2">
                <active.icon className="h-4 w-4 text-primary" />
                <span className="text-sm font-semibold">{active.label}</span>
              </div>
              <div className="flex items-center gap-1">
                <a
                  href={active.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
                  aria-label="Open in new tab"
                >
                  <ExternalLink className="h-4 w-4" />
                </a>
                <button
                  onClick={() => setActive(null)}
                  className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
            <iframe
              src={active.url}
              title={active.label}
              className="h-full w-full flex-1 bg-white"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-presentation"
              referrerPolicy="no-referrer-when-downgrade"
              loading="lazy"
            />
          </div>
        </div>
      )}
    </>
  );
}
