const items = [
  { name: "Tunde A.", city: "Lagos", text: "Lost 11kg in 8 weeks. The macro coach inside the dashboard is unreal." },
  { name: "Chioma O.", city: "Abuja", text: "First time a fitness program actually fit Naija food. Jollof, beans, everything." },
  { name: "Emeka I.", city: "Port Harcourt", text: "Paystack checkout, instant unlock. No drama. ResoFlex Reset changed my mornings." },
  { name: "Aisha B.", city: "Kano", text: "The AI builds my plan weekly. I just show up. Down 2 dress sizes." },
  { name: "Seyi K.", city: "Ibadan", text: "VIP coaching was worth every naira. I've referred 7 friends already." },
];

export function Testimonials() {
  return (
    <section className="px-5 py-12">
      <h2 className="mb-6 text-center text-2xl font-bold md:text-3xl">
        Real Nigerians. Real Results.
      </h2>
      <div className="-mx-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {items.map((t) => (
          <article
            key={t.name}
            className="glass min-w-[280px] max-w-sm snap-start rounded-2xl p-5 sm:min-w-[340px]"
          >
            <p className="text-sm leading-relaxed text-foreground/90">"{t.text}"</p>
            <footer className="mt-4 flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/20 text-sm font-semibold text-primary">
                {t.name[0]}
              </div>
              <div className="text-xs">
                <div className="font-semibold">{t.name}</div>
                <div className="text-muted-foreground">{t.city}</div>
              </div>
            </footer>
          </article>
        ))}
      </div>
    </section>
  );
}
