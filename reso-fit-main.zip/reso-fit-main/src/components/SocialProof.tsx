export function SocialProof() {
  // Seeded by date — stable per day, no hydration mismatch worries (low-stakes UI).
  const day = new Date();
  const seed = day.getUTCFullYear() * 1000 + day.getUTCMonth() * 31 + day.getUTCDate();
  const count = 180 + (seed % 90);
  return (
    <div className="mx-auto flex max-w-md items-center justify-center gap-3 rounded-full border border-border bg-card/50 px-4 py-2 text-sm">
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
      </span>
      <span className="text-muted-foreground">
        <span className="font-semibold text-foreground">{count}</span> Nigerians joined today
      </span>
    </div>
  );
}
