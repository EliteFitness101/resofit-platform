import { useMemo, useState, useEffect } from "react";
import { useRouter } from "@tanstack/react-router";
import { CONTACT } from "@/services/router";

const PHONE = CONTACT.whatsapp.replace(/[^0-9]/g, "");

function buildContextMessage(path: string): string {
  const map: Record<string, string> = {
    "/": "Hi ResoFlex — I'm browsing the landing page and want to learn more.",
    "/shop": "Hi ResoFlex — I'm on the shop page and have a question about your products.",
    "/os": "Hi ResoFlex — I'm exploring the Sovereign OS and need guidance.",
  };
  if (map[path]) return map[path];
  if (path.startsWith("/product/")) {
    const handle = path.split("/product/")[1] || "a product";
    return `Hi ResoFlex — I'm viewing ${handle} and want help ordering.`;
  }
  if (path.startsWith("/admin/")) return "Hi ResoFlex — I'm using the admin console and have a question.";
  return `Hi ResoFlex — I'm on ${path} and want to chat.`;
}

export function WhatsAppFloat() {
  const router = useRouter();
  const [path, setPath] = useState<string>(() => router.state.location.pathname);

  useEffect(() => {
    return router.subscribe("onResolved", () => setPath(router.state.location.pathname));
  }, [router]);

  const href = useMemo(() => {
    const text = encodeURIComponent(buildContextMessage(path));
    return `https://wa.me/${PHONE}?text=${text}`;
  }, [path]);

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Chat on WhatsApp ${CONTACT.whatsapp}`}
      title={`WhatsApp ${CONTACT.whatsapp}`}
      className="group fixed bottom-20 right-4 z-40 flex items-center gap-2 rounded-full bg-[#25D366] px-3 py-3 text-white shadow-lg transition-all duration-300 hover:scale-105 hover:px-4 hover:shadow-2xl md:bottom-6"
    >
      <svg viewBox="0 0 24 24" className="h-6 w-6 shrink-0" fill="currentColor" aria-hidden>
        <path d="M20.52 3.48A11.78 11.78 0 0 0 12.06 0C5.5 0 .2 5.3.2 11.86c0 2.09.55 4.12 1.6 5.92L0 24l6.4-1.67a11.85 11.85 0 0 0 5.66 1.44h.01c6.55 0 11.86-5.3 11.86-11.86 0-3.17-1.24-6.15-3.41-8.43Zm-8.46 18.24h-.01a9.86 9.86 0 0 1-5.03-1.38l-.36-.21-3.8 1 1.02-3.7-.24-.38a9.84 9.84 0 0 1-1.51-5.23c0-5.45 4.43-9.88 9.88-9.88 2.64 0 5.12 1.03 6.99 2.9a9.83 9.83 0 0 1 2.89 6.99c0 5.45-4.43 9.89-9.83 9.89Zm5.42-7.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.66.15-.2.3-.76.97-.94 1.17-.17.2-.34.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.47.13-.62.13-.13.3-.34.45-.51.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.66-1.6-.9-2.18-.24-.57-.48-.5-.66-.5l-.56-.01c-.2 0-.5.07-.77.37-.27.3-1.02 1-1.02 2.44s1.05 2.83 1.2 3.03c.15.2 2.07 3.16 5 4.43.7.3 1.24.48 1.67.62.7.22 1.34.19 1.84.12.56-.08 1.76-.72 2-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.2-.57-.35Z"/>
      </svg>
      <span className="max-w-0 overflow-hidden whitespace-nowrap text-xs font-semibold transition-all duration-300 group-hover:max-w-[160px] group-hover:pr-1">
        {CONTACT.whatsapp}
      </span>
    </a>
  );
}
