import { GlassCard } from "@/components/ui/glass-card";
import { TrendingUp, Crown, AlertTriangle, Users, Target } from "lucide-react";
import { useLocalStorage } from "@/hooks/useLocalStorage";

type Widget = {
  key: string;
  label: string;
  icon: typeof TrendingUp;
  rows: { name: string; value: string; trend?: string }[];
};

const DEFAULT_WIDGETS: Widget[] = [
  {
    key: "trending",
    label: "Trending SKUs",
    icon: TrendingUp,
    rows: [
      { name: "RF-SUP-RESET-103", value: "428 views", trend: "+18%" },
      { name: "RF-EQP-HEX10-221", value: "312 views", trend: "+11%" },
      { name: "RF-WEL-GLOW-077", value: "289 views", trend: "+9%" },
    ],
  },
  {
    key: "converters",
    label: "Top Converters",
    icon: Crown,
    rows: [
      { name: "Sovereign Reset Kit", value: "6.4% CVR", trend: "+0.8" },
      { name: "Hex Dumbbell 10kg", value: "5.1% CVR", trend: "+0.4" },
      { name: "Glow Launch Bundle", value: "4.7% CVR", trend: "+0.2" },
    ],
  },
  {
    key: "inventory",
    label: "Low-Inventory Alerts",
    icon: AlertTriangle,
    rows: [
      { name: "RF-SUP-RESET-103", value: "12 left" },
      { name: "RF-EQP-MAT-018", value: "8 left" },
      { name: "RF-WEL-GLOW-077", value: "5 left" },
    ],
  },
  {
    key: "referral",
    label: "Referral Performance",
    icon: Users,
    rows: [
      { name: "WhatsApp VIP", value: "₦412k", trend: "+24%" },
      { name: "TikTok Spark", value: "₦298k", trend: "+12%" },
      { name: "Email Flow", value: "₦141k", trend: "+6%" },
    ],
  },
  {
    key: "roas",
    label: "Top ROAS Products",
    icon: Target,
    rows: [
      { name: "Sovereign Reset", value: "4.6x" },
      { name: "Glow Launch", value: "3.9x" },
      { name: "Hex Dumbbell", value: "3.2x" },
    ],
  },
];

export function CommerceDashboard() {
  const [widgets] = useLocalStorage<Widget[]>("resoflex:commerce-widgets", DEFAULT_WIDGETS);

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {widgets.map((w) => (
        <GlassCard key={w.key} className="p-4">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
            <span>{w.label}</span>
            <w.icon className="h-3.5 w-3.5 text-primary" />
          </div>
          <ul className="mt-3 space-y-2">
            {w.rows.map((r) => (
              <li key={r.name} className="flex items-center justify-between gap-2 text-xs">
                <span className="truncate text-foreground/90">{r.name}</span>
                <span className="flex items-center gap-2 text-muted-foreground">
                  {r.value}
                  {r.trend && (
                    <span className="rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                      {r.trend}
                    </span>
                  )}
                </span>
              </li>
            ))}
          </ul>
        </GlassCard>
      ))}
    </div>
  );
}
