import { ECOSYSTEM } from "@/services/router";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section className="relative overflow-hidden px-5 pt-16 pb-10 md:pt-28 md:pb-20">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(60% 50% at 50% 0%, color-mix(in oklab, var(--primary) 18%, transparent), transparent 70%)",
        }}
      />
      <div className="mx-auto max-w-3xl text-center">
        <span className="glass inline-block rounded-full px-3 py-1 text-xs tracking-wide text-primary">
          ResoFit AI · Sovereign Body OS
        </span>
        <h1 className="mt-5 text-4xl font-bold leading-tight md:text-6xl">
          Transform Your Body.{" "}
          <span className="text-gradient-gold">Own Your Future.</span>
        </h1>
        <p className="mt-4 text-base text-muted-foreground md:text-lg">
          The AI-powered fitness, nutrition and supplement OS built for Nigerians who
          refuse average. One system. One transformation. One payment.
        </p>
        <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Button asChild size="lg" className="shadow-gold w-full sm:w-auto">
            <a href={`/go?intent=checkout`}>Start My Transformation →</a>
          </Button>
          <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
            <a href={ECOSYSTEM.evolution} rel="noopener">See How It Works</a>
          </Button>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          Secure Paystack checkout · Instant access · 100% Nigerian owned
        </p>
      </div>
    </section>
  );
}
