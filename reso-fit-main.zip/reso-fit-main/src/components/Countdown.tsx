import { useEffect, useState } from "react";

function endOfDay() {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d.getTime();
}

export function Countdown() {
  const [ms, setMs] = useState<number | null>(null);
  useEffect(() => {
    setMs(endOfDay() - Date.now());
    const id = setInterval(() => setMs(endOfDay() - Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const s = ms == null ? 0 : Math.max(0, Math.floor(ms / 1000));
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const sec = String(s % 60).padStart(2, "0");
  return (
    <div className="glass mx-auto flex max-w-md items-center justify-between rounded-xl px-5 py-4">
      <span className="text-sm text-muted-foreground">Launch pricing ends in</span>
      <span className="font-mono text-xl font-bold text-primary tabular-nums">
        {ms == null ? "--:--:--" : `${h}:${m}:${sec}`}
      </span>
    </div>
  );
}
