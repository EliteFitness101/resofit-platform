import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  { q: "How does payment work?", a: "Secure checkout via Paystack. After payment is verified, your dashboard unlocks automatically — no waiting, no manual approval." },
  { q: "Will this work with Nigerian food?", a: "Yes. Every macro plan is built around jollof, eba, beans, plantain, suya — real food, no kale obsession." },
  { q: "Do I need a gym?", a: "No. The program adapts: home workouts, outdoor runs, or full gym. The AI builds around what you have." },
  { q: "What if it doesn't work for me?", a: "Follow the system for 30 days. If you don't see measurable results, contact support inside the dashboard." },
  { q: "Can I cancel anytime?", a: "Yes. One-time payment for core access. Premium coaching is optional and cancellable monthly." },
];

export function FAQ() {
  return (
    <section className="mx-auto max-w-2xl px-5 py-12">
      <h2 className="mb-6 text-center text-2xl font-bold md:text-3xl">Questions, answered.</h2>
      <Accordion type="single" collapsible className="glass rounded-2xl px-5">
        {faqs.map((f, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="border-border/60 last:border-0">
            <AccordionTrigger className="text-left">{f.q}</AccordionTrigger>
            <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}
