import { useEffect, useState } from "react";
import { ECOSYSTEM } from "@/services/router";
import { ChevronDown, Menu, X, Flame, Dumbbell, ShoppingBag, Sparkles, ShieldCheck } from "lucide-react";

type SubItem = { label: string; desc: string; href: string; external?: boolean };
type NavItem = { label: string; icon: React.ComponentType<{ className?: string }>; items: SubItem[] };

const NAV: NavItem[] = [
  {
    label: "Transform",
    icon: Flame,
    items: [
      { label: "ResoFit Evolution", desc: "Returning user funnel", href: ECOSYSTEM.evolution, external: true },
      { label: "ResoFit Reset", desc: "30-day reset protocol", href: ECOSYSTEM.reset, external: true },
      { label: "Glow Launch", desc: "Skin + body glow stack", href: ECOSYSTEM.glow, external: true },
    ],
  },
  {
    label: "Train",
    icon: Dumbbell,
    items: [
      { label: "NowNow Gym", desc: "Home + outdoor workouts", href: ECOSYSTEM.nownowgym, external: true },
      { label: "ResoGold", desc: "Elite training system", href: ECOSYSTEM.resogold, external: true },
      { label: "Sovereign Gold Flow", desc: "Premium movement OS", href: ECOSYSTEM.goldFlow, external: true },
    ],
  },
  {
    label: "Shop",
    icon: ShoppingBag,
    items: [
      { label: "Elite Products", desc: "VIP supplement vault", href: ECOSYSTEM.elite, external: true },
      { label: "Naija Elite Store", desc: "Marketplace", href: ECOSYSTEM.naijaStore, external: true },
      { label: "ResoFlex Reset", desc: "Flagship supplement", href: ECOSYSTEM.supplement, external: true },
    ],
  },
  {
    label: "VIP",
    icon: Sparkles,
    items: [
      { label: "Sovereign Gateway OS", desc: "Ecosystem intelligence dashboard", href: "/os" },
      { label: "Catalog AI Console", desc: "Generate Shopify-ready product specs", href: "/admin/catalog-ai" },
      { label: "Replay Intelligence", desc: "TikTok viral moment extractor", href: "/admin/replay-intel" },
      { label: "Ads Intelligence", desc: "ROAS creative engine", href: "/admin/ads-intel" },
      { label: "Elite Coaching", desc: "1-on-1 transformation", href: "/go?intent=vip" },
      { label: "Sovereign Vault", desc: "Members-only intel", href: ECOSYSTEM.vault, external: true },
      { label: "Sign In", desc: "Access your account", href: ECOSYSTEM.auth, external: true },
    ],
  },
];

const MILESTONES = [
  { pct: 10, label: "Browse" },
  { pct: 35, label: "Engage" },
  { pct: 65, label: "Decide" },
  { pct: 100, label: "Transform" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      const p = max > 0 ? Math.min(100, Math.round((h.scrollTop / max) * 100)) : 0;
      setProgress(p);
      setScrolled(h.scrollTop > 8);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const current = MILESTONES.find((m) => progress <= m.pct) ?? MILESTONES[MILESTONES.length - 1];

  return (
    <header
      className={`sticky top-0 z-50 transition-all ${
        scrolled ? "border-b border-border/60 bg-background/85 backdrop-blur-lg" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
        <a href="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground shadow-gold">
            <ShieldCheck className="h-4 w-4" />
          </span>
          <span className="text-base font-bold tracking-tight">
            Reso<span className="text-gradient-gold">Fit</span>
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex" onMouseLeave={() => setOpen(null)}>
          {NAV.map((item) => (
            <div key={item.label} className="relative" onMouseEnter={() => setOpen(item.label)}>
              <button
                className={`group flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  open === item.label ? "text-primary" : "text-foreground/80 hover:text-primary"
                }`}
              >
                <item.icon className="h-4 w-4 opacity-70 transition-transform group-hover:scale-110" />
                {item.label}
                <ChevronDown
                  className={`h-3.5 w-3.5 transition-transform ${open === item.label ? "rotate-180" : ""}`}
                />
              </button>

              {open === item.label && (
                <div className="absolute left-1/2 top-full z-50 w-72 -translate-x-1/2 pt-2 animate-in fade-in-0 zoom-in-95 duration-150">
                  <div className="glass overflow-hidden rounded-xl p-2 shadow-gold">
                    {item.items.map((sub) => (
                      <a
                        key={sub.label}
                        href={sub.href}
                        {...(sub.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                        className="group block rounded-lg px-3 py-2.5 transition-colors hover:bg-primary/10"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-foreground group-hover:text-primary">
                            {sub.label}
                          </span>
                          <span className="text-xs text-primary opacity-0 transition-opacity group-hover:opacity-100">
                            →
                          </span>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground">{sub.desc}</p>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="/go?intent=checkout"
            className="hidden rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-105 md:inline-flex"
          >
            Start Now
          </a>
          <button
            className="rounded-md border border-border p-2 md:hidden"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Milestone progress bar */}
      <div className="relative h-[3px] w-full bg-border/40">
        <div
          className="absolute inset-y-0 left-0 transition-[width] duration-300"
          style={{
            width: `${progress}%`,
            background: "var(--gradient-gold)",
          }}
        />
      </div>
      <div className="mx-auto hidden max-w-6xl items-center justify-between px-5 py-1.5 text-[10px] uppercase tracking-widest text-muted-foreground md:flex">
        {MILESTONES.map((m) => (
          <span
            key={m.label}
            className={`transition-colors ${current.label === m.label ? "font-semibold text-primary" : ""}`}
          >
            {m.label}
          </span>
        ))}
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="border-t border-border/60 bg-background/95 backdrop-blur-lg md:hidden">
          <div className="space-y-1 px-3 py-3">
            {NAV.map((item) => (
              <details key={item.label} className="group rounded-lg">
                <summary className="flex cursor-pointer items-center justify-between rounded-md px-3 py-2.5 text-sm font-medium hover:bg-primary/10">
                  <span className="flex items-center gap-2">
                    <item.icon className="h-4 w-4 text-primary" />
                    {item.label}
                  </span>
                  <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
                </summary>
                <div className="mt-1 space-y-0.5 pl-9 pr-2">
                  {item.items.map((sub) => (
                    <a
                      key={sub.label}
                      href={sub.href}
                      {...(sub.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
                      className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-primary/5 hover:text-primary"
                      onClick={() => setMobileOpen(false)}
                    >
                      {sub.label}
                      <span className="block text-[11px] opacity-70">{sub.desc}</span>
                    </a>
                  ))}
                </div>
              </details>
            ))}
            <a
              href="/go?intent=checkout"
              className="mt-2 flex items-center justify-center rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-gold"
            >
              Start Now — Secure Checkout
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
