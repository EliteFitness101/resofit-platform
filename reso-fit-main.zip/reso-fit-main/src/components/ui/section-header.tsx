import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface SectionHeaderProps {
  eyebrow?: string;
  eyebrowIcon?: LucideIcon;
  title: React.ReactNode;
  description?: React.ReactNode;
  className?: string;
}

export function SectionHeader({ eyebrow, eyebrowIcon: Icon, title, description, className }: SectionHeaderProps) {
  return (
    <div className={cn("", className)}>
      {eyebrow && (
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary/80">
          {Icon && <Icon className="h-3.5 w-3.5" />} {eyebrow}
        </div>
      )}
      <h1 className="mt-2 text-2xl font-bold sm:text-3xl md:text-4xl">{title}</h1>
      {description && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{description}</p>}
    </div>
  );
}
