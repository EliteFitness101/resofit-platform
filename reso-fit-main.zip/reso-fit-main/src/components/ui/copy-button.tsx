import { Copy } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface CopyButtonProps {
  text: string;
  label?: string;
  className?: string;
  size?: "sm" | "md";
}

export function CopyButton({ text, label = "Copy", className, size = "sm" }: CopyButtonProps) {
  return (
    <button
      type="button"
      onClick={() => navigator.clipboard.writeText(text).then(() => toast.success("Copied"))}
      className={cn(
        "inline-flex items-center gap-1 text-primary hover:underline",
        size === "sm" ? "text-[11px]" : "text-xs",
        className,
      )}
    >
      <Copy className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} /> {label}
    </button>
  );
}
