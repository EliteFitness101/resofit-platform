import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

const KEY = "resofit:exit-intent-dismissed";

export function ExitIntent() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(KEY)) return;
    const onLeave = (e: MouseEvent) => {
      if (e.clientY <= 0) {
        setOpen(true);
        sessionStorage.setItem(KEY, "1");
        document.removeEventListener("mouseout", onLeave);
      }
    };
    document.addEventListener("mouseout", onLeave);
    return () => document.removeEventListener("mouseout", onLeave);
  }, []);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={() => setOpen(false)}>
      <div className="glass max-w-sm rounded-2xl p-6 text-center" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-xl font-bold">Wait — claim your launch discount</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Use code <span className="font-mono font-bold text-primary">RESO10</span> for 10% off at checkout. Today only.
        </p>
        <Button asChild className="mt-5 w-full">
          <a href="/go?intent=checkout">Claim 10% Off →</a>
        </Button>
        <button
          onClick={() => setOpen(false)}
          className="mt-3 text-xs text-muted-foreground underline"
        >
          No thanks, I'll pay full price
        </button>
      </div>
    </div>
  );
}
