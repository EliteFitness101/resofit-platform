import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export function BMICalculator() {
  const [h, setH] = useState("");
  const [w, setW] = useState("");
  const bmi = (() => {
    const hn = parseFloat(h);
    const wn = parseFloat(w);
    if (!hn || !wn || hn < 50) return null;
    return wn / Math.pow(hn / 100, 2);
  })();
  const label = bmi == null ? "" :
    bmi < 18.5 ? "Underweight" :
    bmi < 25 ? "Healthy" :
    bmi < 30 ? "Overweight" : "Obese";

  return (
    <section className="mx-auto max-w-md px-5 py-12">
      <div className="glass rounded-2xl p-6">
        <h2 className="text-xl font-bold">Quick BMI Check</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Know your number. The dashboard builds your plan around it.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="bmi-h">Height (cm)</Label>
            <Input id="bmi-h" inputMode="numeric" value={h} onChange={(e) => setH(e.target.value)} placeholder="175" />
          </div>
          <div>
            <Label htmlFor="bmi-w">Weight (kg)</Label>
            <Input id="bmi-w" inputMode="numeric" value={w} onChange={(e) => setW(e.target.value)} placeholder="80" />
          </div>
        </div>
        {bmi != null && (
          <div className="mt-5 flex items-center justify-between rounded-lg bg-primary/10 px-4 py-3">
            <span className="text-sm text-muted-foreground">Your BMI</span>
            <span className="text-lg font-bold text-primary">
              {bmi.toFixed(1)} · {label}
            </span>
          </div>
        )}
        <Button asChild className="mt-5 w-full">
          <a href="/go?intent=checkout">Get My Personalized Plan</a>
        </Button>
      </div>
    </section>
  );
}
