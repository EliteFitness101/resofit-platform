export function StickyCTA() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border/60 bg-background/85 px-4 py-3 backdrop-blur md:hidden">
      <a
        href="/go?intent=checkout"
        className="flex w-full items-center justify-center rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-gold"
      >
        Start Now — Secure Checkout
      </a>
    </div>
  );
}
