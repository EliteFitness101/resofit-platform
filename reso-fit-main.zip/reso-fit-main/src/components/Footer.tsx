import { Mail, MessageCircle, Music2 } from "lucide-react";
import { CONTACT, ECOSYSTEM } from "@/services/router";

const EMAIL_LINKS: Array<{ label: string; addr: string }> = [
  { label: "General", addr: CONTACT.emails.general },
  { label: "Payments", addr: CONTACT.emails.payment },
  { label: "Support", addr: CONTACT.emails.support },
  { label: "Recruit", addr: CONTACT.emails.recruit },
  { label: "Invest", addr: CONTACT.emails.invest },
];

export function Footer() {
  return (
    <footer id="contact" className="border-t border-border/60 bg-background/60">
      <div className="mx-auto max-w-6xl px-5 py-10">
        <div className="grid gap-8 md:grid-cols-3">
          <div>
            <h3 className="text-base font-bold">
              Reso<span className="text-gradient-gold">Fit</span>
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Sovereign AI Body OS · Lagos, Nigeria
            </p>
            <div className="mt-4 flex items-center gap-3">
              <a
                href={ECOSYSTEM.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[#25D366] text-white transition-transform hover:scale-110"
              >
                <MessageCircle className="h-4 w-4" />
              </a>
              <a
                href={ECOSYSTEM.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="TikTok @resoflex2"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-foreground text-background transition-transform hover:scale-110"
              >
                <Music2 className="h-4 w-4" />
              </a>
              <a
                href={ECOSYSTEM.tiktokAlt}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="TikTok @resonancefitness"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-background text-foreground transition-transform hover:scale-110"
              >
                <Music2 className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Talk to us
            </h4>
            <a
              href={ECOSYSTEM.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary"
            >
              <MessageCircle className="h-4 w-4 text-[#25D366]" />
              WhatsApp {CONTACT.whatsapp}
            </a>
            <p className="mt-2 text-xs text-muted-foreground">
              Fastest response · 7 days a week
            </p>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Email
            </h4>
            <ul className="mt-3 space-y-1.5">
              {EMAIL_LINKS.map((e) => (
                <li key={e.addr}>
                  <a
                    href={`mailto:${e.addr}`}
                    className="group flex items-center gap-2 text-sm text-foreground/80 hover:text-primary"
                  >
                    <Mail className="h-3.5 w-3.5 opacity-60 group-hover:opacity-100" />
                    <span className="font-medium">{e.label}:</span>
                    <span className="text-muted-foreground group-hover:text-primary">
                      {e.addr}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-border/60 pt-5 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} ResoFit · Sovereign Body OS · All rights reserved
        </div>
      </div>
    </footer>
  );
}
