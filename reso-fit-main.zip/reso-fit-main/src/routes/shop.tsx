import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Dumbbell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CartDrawer } from "@/components/CartDrawer";
import { useCartSync } from "@/hooks/useCartSync";
import { useCartStore } from "@/stores/cartStore";
import { PRODUCTS_QUERY, storefrontApiRequest, type ShopifyProduct } from "@/lib/shopify";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Shop Dumbbells — ResoFit" },
      { name: "description", content: "Premium dumbbells and home gym gear, shipped fast across Nigeria." },
      { property: "og:title", content: "Shop Dumbbells — ResoFit" },
      { property: "og:description", content: "Premium dumbbells and home gym gear, shipped fast across Nigeria." },
    ],
  }),
  component: ShopPage,
});

async function fetchDumbbells(): Promise<ShopifyProduct[]> {
  const data = await storefrontApiRequest(PRODUCTS_QUERY, {
    first: 24,
    query: "title:dumbbell* OR product_type:Dumbbells OR tag:dumbbell",
  });
  const edges = data?.data?.products?.edges || [];
  return edges as ShopifyProduct[];
}

function ShopPage() {
  useCartSync();
  const { data: products, isLoading, error } = useQuery({
    queryKey: ["shop", "dumbbells"],
    queryFn: fetchDumbbells,
  });

  return (
    <main className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <Link to="/" className="text-lg font-bold">
            Reso<span className="text-gradient-gold">Fit</span> Shop
          </Link>
          <CartDrawer />
        </div>
      </header>

      <section className="container mx-auto px-4 py-12">
        <div className="mb-10 flex flex-col items-start gap-3">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground">
            <Dumbbell className="h-3.5 w-3.5" /> Home Gym Essentials
          </div>
          <h1 className="text-4xl font-bold tracking-tight md:text-5xl">Dumbbells</h1>
          <p className="max-w-xl text-muted-foreground">
            Hand-picked dumbbells for strength, sculpting, and rehab. Real Shopify inventory — secure checkout.
          </p>
        </div>

        {isLoading && (
          <div className="flex items-center justify-center py-24 text-muted-foreground">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading products…
          </div>
        )}

        {error && (
          <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-6 text-sm text-destructive">
            Couldn't load products. Try again shortly.
          </div>
        )}

        {!isLoading && !error && products && products.length === 0 && (
          <div className="rounded-2xl border border-dashed bg-card/40 p-10 text-center">
            <Dumbbell className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
            <h2 className="text-xl font-semibold">No products yet</h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
              Your Shopify store has no dumbbell products. Tell the chat what dumbbell to add (name, weight, price) and
              we'll create it live in your store.
            </p>
          </div>
        )}

        {products && products.length > 0 && (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {products.map((p) => (
              <ProductCard key={p.node.id} product={p} />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

function ProductCard({ product }: { product: ShopifyProduct }) {
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);
  const variant = product.node.variants.edges[0]?.node;
  const image = product.node.images.edges[0]?.node;
  const price = product.node.priceRange.minVariantPrice;

  const handleAdd = async () => {
    if (!variant) return;
    await addItem({
      product,
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
  };

  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border bg-card transition-all hover:shadow-lg">
      <Link
        to="/product/$handle"
        params={{ handle: product.node.handle }}
        className="aspect-square overflow-hidden bg-secondary/30"
      >
        {image ? (
          <img
            src={image.url}
            alt={image.altText || product.node.title}
            className="h-full w-full object-cover transition-transform group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full items-center justify-center">
            <Dumbbell className="h-16 w-16 text-muted-foreground/40" />
          </div>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex-1">
          <h3 className="font-semibold leading-tight">{product.node.title}</h3>
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{product.node.description}</p>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold">
            {price.currencyCode} {parseFloat(price.amount).toFixed(2)}
          </span>
          <Button onClick={handleAdd} disabled={!variant || isLoading} size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Add to Cart"}
          </Button>
        </div>
      </div>
    </div>
  );
}
