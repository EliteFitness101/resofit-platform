import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { resolveDestination, flags, type Intent } from "@/services/router";

export const Route = createFileRoute("/go")({
  validateSearch: (s: Record<string, unknown>) => ({
    intent: typeof s.intent === "string" ? (s.intent as Intent) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Routing… — ResoFit" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Go,
});

function Go() {
  const { intent } = Route.useSearch();

  useEffect(() => {
    flags.markReturning();
    const dest = resolveDestination(intent);
    window.location.replace(dest);
  }, [intent]);

  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <div className="glass rounded-2xl p-8 text-center">
        <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
        <p className="mt-4 text-sm text-muted-foreground">Routing you to the right experience…</p>
      </div>
    </main>
  );
}
