import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { ECOSYSTEM, flags } from "@/services/router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/success")({
  // We intentionally ignore any query params here. Payment verification
  // happens in the checkout app (joy-funnel-ai) and access enforcement
  // happens in the destination app (reso-flex-pwa). This page is purely
  // a branded "thanks, head to your dashboard" landing.
  head: () => ({
    meta: [
      { title: "Payment Successful — ResoFit" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Success,
});

function Success() {
  useEffect(() => {
    flags.markReturning();
    const t = setTimeout(() => window.location.replace(ECOSYSTEM.dashboard), 2500);
    return () => clearTimeout(t);
  }, []);

  return (
    <main className="flex min-h-screen items-center justify-center px-5">
      <div className="glass w-full max-w-md rounded-2xl p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/20 text-3xl">
          ✓
        </div>
        <h1 className="mt-4 text-2xl font-bold">Welcome to ResoFit.</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Taking you to your dashboard. You'll be asked to sign in there so your
          access can be verified securely.
        </p>
        <Button asChild className="mt-6 w-full">
          <a href={ECOSYSTEM.dashboard}>Open Dashboard →</a>
        </Button>
      </div>
    </main>
  );
}
