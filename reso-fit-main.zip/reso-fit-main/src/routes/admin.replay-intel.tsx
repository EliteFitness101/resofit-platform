import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Film, Sparkles, Scissors, TrendingUp, Copy, Upload, Download, FileJson } from "lucide-react";
import { toast } from "sonner";
import { useLocalStorage } from "@/hooks/useLocalStorage";

export const Route = createFileRoute("/admin/replay-intel")({
  head: () => ({
    meta: [
      { title: "Replay Intelligence — TikTok Viral Clip Engine | ResoFlex OS" },
      { name: "description", content: "Extract viral TikTok moments, score clips, generate captions and export full metadata to CSV/JSON for the ResoFlex creator engine." },
      { property: "og:title", content: "Replay Intelligence — ResoFlex Creator OS" },
      { property: "og:description", content: "AI-powered viral clip extraction with ranked scoring and TikTok-ready exports." },
    ],
  }),
  component: ReplayIntel,
});

type Clip = {
  id: string;
  start: string;
  end: string;
  score: number;
  hook: string;
  caption: string;
  hashtags: string[];
};

function scoreClips(title: string, durationSec: number): Clip[] {
  const t = title.trim() || "Sovereign Reset Replay";
  const slots = Math.max(3, Math.min(6, Math.round(durationSec / 60)));
  const hooks = [
    "POV: you finally cracked the protocol",
    "Watch what 30 days did to her body",
    "Nobody talks about this glow shift",
    "Why Lagos women keep restocking this",
    "The 7-second decision that changed everything",
    "Stop scrolling — this is the unlock",
  ];
  const out: Clip[] = [];
  for (let i = 0; i < slots; i++) {
    const start = Math.floor((durationSec / slots) * i);
    const len = 14 + Math.floor(Math.random() * 18);
    const end = Math.min(durationSec, start + len);
    const score = +(0.62 + Math.random() * 0.36).toFixed(2);
    const hook = hooks[i % hooks.length];
    out.push({
      id: `clip-${i + 1}`,
      start: fmt(start),
      end: fmt(end),
      score,
      hook,
      caption: `${hook} → ${t}. Comment GLOW for the drop.`,
      hashtags: ["#resoflex", "#sovereignglow", "#naijafitness", "#fyp", "#transformation"],
    });
  }
  return out.sort((a, b) => b.score - a.score);
}

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, "0")}`;
}

function copy(t: string) {
  navigator.clipboard.writeText(t).then(() => toast.success("Copied"));
}

function ReplayIntel() {
  const [title, setTitle] = useLocalStorage<string>("resoflex:replay-title", "");
  const [duration, setDuration] = useLocalStorage<number>("resoflex:replay-duration", 420);
  const [filename, setFilename] = useState<string | null>(null);
  const [clips, setClips] = useLocalStorage<Clip[] | null>("resoflex:replay-clips", null);

  const stats = useMemo(() => {
    if (!clips) return null;
    const avg = (clips.reduce((s, c) => s + c.score, 0) / clips.length).toFixed(2);
    const viral = clips.filter((c) => c.score >= 0.85).length;
    return { avg, viral, total: clips.length };
  }, [clips]);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFilename(f.name);
    if (!title) setTitle(f.name.replace(/\.[^.]+$/, ""));
    toast.success("Replay queued for local analysis");
  };

  const run = () => {
    setClips(scoreClips(title, duration));
    toast.success("Viral moments extracted");
  };

  const download = (content: string, name: string, mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(`${name} downloaded`);
  };

  const exportCSV = () => {
    if (!clips) return;
    const ts = new Date().toISOString();
    const header = ["id", "start", "end", "score", "hook", "caption", "hashtags", "exported_at"];
    const rows = clips.map((c) => [
      c.id,
      c.start,
      c.end,
      String(c.score),
      `"${c.hook.replace(/"/g, '""')}"`,
      `"${c.caption.replace(/"/g, '""')}"`,
      `"${c.hashtags.join(" ")}"`,
      ts,
    ].join(","));
    download([header.join(","), ...rows].join("\n"), `replay-${ts.slice(0, 10)}.csv`, "text/csv");
  };

  const exportJSON = () => {
    if (!clips) return;
    const ts = new Date().toISOString();
    const payload = { title, duration, exported_at: ts, total: clips.length, clips };
    download(JSON.stringify(payload, null, 2), `replay-${ts.slice(0, 10)}.json`, "application/json");
  };

  return (
    <main className="min-h-screen pb-24">
      <Nav />
      <section className="mx-auto max-w-6xl px-5 pt-8">
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary/80">
          <Film className="h-3.5 w-3.5" /> Admin · Replay Intelligence
        </div>
        <h1 className="mt-2 text-3xl font-bold md:text-4xl">
          TikTok <span className="text-gradient-gold">Replay Engine</span>
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Extract viral moments, score clips and export TikTok-ready captions. Local processing — no heavy media pipeline.
        </p>
      </section>

      <section className="mx-auto mt-6 grid max-w-6xl gap-5 px-5 lg:grid-cols-[1fr_1.4fr]">
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Upload className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-bold uppercase tracking-wider">Replay Source</h2>
          </div>
          <div className="mt-4 space-y-3">
            <label className="block">
              <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">Replay title / topic</span>
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="e.g. 30-day Sovereign Reset Q&A"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">Approx duration (sec)</span>
              <input
                type="number"
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                value={duration}
                onChange={(e) => setDuration(Math.max(60, +e.target.value || 60))}
              />
            </label>
            <label className="block cursor-pointer rounded-md border border-dashed border-border bg-background/30 p-4 text-center text-xs text-muted-foreground hover:border-primary/60 hover:text-primary">
              <input type="file" accept="video/*" className="hidden" onChange={onFile} />
              {filename ? `Loaded: ${filename}` : "Drop or pick a replay file (optional)"}
            </label>
            <button
              onClick={run}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-gold"
            >
              <Sparkles className="h-4 w-4" /> Extract viral moments
            </button>
            <p className="text-[11px] text-muted-foreground">
              Runs locally. Scoring uses heuristic hooks + engagement priors. No upload, no tokens.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {!clips && (
            <div className="glass flex h-full min-h-[300px] flex-col items-center justify-center rounded-2xl p-10 text-center">
              <Scissors className="h-8 w-8 text-primary" />
              <h3 className="mt-3 text-sm font-bold">Awaiting replay analysis</h3>
              <p className="mt-1 max-w-sm text-xs text-muted-foreground">
                Add a title and run extraction. You'll get ranked clips with captions and TikTok hashtags.
              </p>
            </div>
          )}

          {clips && stats && (
            <>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { k: "Avg Clip Score", v: stats.avg, icon: TrendingUp },
                  { k: "Viral-grade", v: `${stats.viral}/${stats.total}`, icon: Sparkles },
                  { k: "Total clips", v: String(stats.total), icon: Scissors },
                ].map((s) => (
                  <div key={s.k} className="glass rounded-xl p-4">
                    <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
                      <span>{s.k}</span>
                      <s.icon className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <div className="mt-1 text-lg font-bold">{s.v}</div>
                  </div>
                ))}
              </div>

              <div className="glass rounded-2xl p-5">
                <div className="mb-3 flex items-center gap-2">
                  <Scissors className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider">Ranked Clips</h3>
                </div>
                <div className="space-y-3">
                  {clips.map((c) => (
                    <div key={c.id} className="rounded-xl border border-border/40 bg-background/30 p-4">
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-semibold">{c.hook}</div>
                        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                          <span>{c.start} → {c.end}</span>
                          <span
                            className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                            style={{
                              background: c.score >= 0.85 ? "var(--gradient-gold)" : "color-mix(in oklab, var(--primary) 15%, transparent)",
                              color: c.score >= 0.85 ? "hsl(var(--primary-foreground))" : "hsl(var(--primary))",
                            }}
                          >
                            {c.score.toFixed(2)}
                          </span>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-foreground/90">{c.caption}</p>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        {c.hashtags.map((h) => (
                          <span key={h} className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] text-foreground">{h}</span>
                        ))}
                        <button
                          onClick={() => copy(`${c.caption}\n${c.hashtags.join(" ")}`)}
                          className="ml-auto inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
                        >
                          <Copy className="h-3 w-3" /> Copy TikTok caption
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => copy(JSON.stringify(clips, null, 2))}
                    className="inline-flex items-center gap-2 rounded-md border border-border bg-background/40 px-3 py-2 text-xs font-medium hover:bg-primary/10"
                  >
                    <Copy className="h-3.5 w-3.5" /> Copy JSON
                  </button>
                  <button
                    onClick={exportJSON}
                    className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-3 py-2 text-xs font-semibold hover:bg-primary/20"
                  >
                    <FileJson className="h-3.5 w-3.5" /> Download JSON
                  </button>
                  <button
                    onClick={exportCSV}
                    className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground shadow-gold"
                  >
                    <Download className="h-3.5 w-3.5" /> Download CSV
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </section>
      <Footer />
    </main>
  );
}
