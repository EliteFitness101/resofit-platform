import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Brain, Copy, Sparkles, Tag, Package, Image as ImageIcon, ShieldCheck, CheckCircle2, AlertTriangle, Rocket } from "lucide-react";
import { toast } from "sonner";
import { useLocalStorage } from "@/hooks/useLocalStorage";


export const Route = createFileRoute("/admin/catalog-ai")({
  head: () => ({
    meta: [
      { title: "Catalog AI Console — Shopify-ready Product Intelligence | ResoFlex" },
      { name: "description", content: "Generate Shopify-ready product metadata, SEO keywords, image prompts, SKUs and export specs with AI-powered validation and duplicate prevention." },
      { property: "og:title", content: "Catalog AI Console — ResoFlex Commerce OS" },
      { property: "og:description", content: "AI commerce console for Shopify-ready product metadata and global e-commerce assets." },
    ],
  }),
  component: CatalogAI,
});

type Inputs = {
  name: string;
  category: string;
  benefit: string;
  audience: string;
  priceNGN: string;
  weightKg: string;
};

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").slice(0, 60);
}

function sku(name: string, category: string) {
  const a = (category || "GEN").replace(/[^a-zA-Z]/g, "").slice(0, 3).toUpperCase() || "GEN";
  const b = name.replace(/[^a-zA-Z0-9]/g, "").slice(0, 6).toUpperCase() || "ITEM";
  const n = Math.floor(100 + Math.random() * 899);
  return `RF-${a}-${b}-${n}`;
}

function generate(i: Inputs) {
  const n = i.name || "Untitled Product";
  const cat = i.category || "Wellness";
  const benefit = i.benefit || "performance + recovery";
  const audience = i.audience || "modern athletes";
  const handle = slugify(`${n}-${cat}`);
  const titles = [
    `${n} — Sovereign ${cat} for ${audience}`,
    `${n} | ${cat} Engineered for ${benefit}`,
    `ResoFlex ${n}: ${cat} Built for ${audience}`,
  ];
  const description = `${n} is a sovereign-grade ${cat.toLowerCase()} solution engineered to deliver ${benefit}. Crafted for ${audience}, it integrates into the ResoFlex ecosystem with daily, weekly and ritual-grade protocols. Lightweight, export-ready and compliant with global commerce standards.`;
  const exportDesc = `${n} — ${cat} product. Materials: compliant, customs-safe. Country of origin: Nigeria. HS code: placeholder. Net weight: ${i.weightKg || "0.50"} kg. Intended use: personal wellness. Not a medical device.`;
  const keywords = [
    n.toLowerCase(),
    `${cat.toLowerCase()} for ${audience.toLowerCase()}`,
    `${benefit.toLowerCase()}`,
    `resoflex ${cat.toLowerCase()}`,
    `buy ${n.toLowerCase()} nigeria`,
    `sovereign ${cat.toLowerCase()}`,
  ];
  const tags = ["resoflex", "sovereign", cat.toLowerCase(), audience.toLowerCase().replace(/\s+/g, "-"), "global-shipping", "export-ready"];
  const collections = [`${cat} — Core`, "Sovereign Essentials", "Global Export", "ResoFit Ecosystem"];
  const upsells = [
    "ResoFlex Reset (supplement)",
    "NowNow Gym (training subscription)",
    "Sovereign Gold Flow (premium movement)",
  ];
  const imagePrompts = {
    hero: `Editorial hero shot of ${n}, ${cat.toLowerCase()} product, soft gold rim light, matte black studio backdrop, premium minimalist composition, 4k, shallow depth of field, ResoFlex brand aesthetic.`,
    lifestyle: `${audience} using ${n} in a sunlit Lagos rooftop gym, candid documentary style, golden hour, natural skin tones, aspirational wellness vibe.`,
    closeup: `Macro close-up of ${n} surface texture and label, dramatic side lighting, sovereign gold accents, ultra sharp detail, product hero for e-commerce.`,
    packaging: `${n} packaging flat-lay, kraft + matte black box with embossed ResoFlex sigil, gold foil typography, accessories arranged symmetrically, top-down shot.`,
  };
  return {
    titles,
    handle,
    description,
    exportDesc,
    keywords,
    tags,
    collections,
    upsells,
    imagePrompts,
    sku: sku(n, cat),
    gtin: `RF-GTIN-${Date.now().toString().slice(-10)}`,
    shipping: {
      weightKg: i.weightKg || "0.50",
      hs: "placeholder",
      origin: "NG",
      customsWording: "Personal wellness product. Not for resale on restricted channels.",
    },
    priceNGN: i.priceNGN || "—",
  };
}

function copy(text: string, label = "Copied") {
  navigator.clipboard.writeText(text).then(() => toast.success(label));
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

type Stage = "idle" | "draft" | "approved" | "published";

function validate(p: ReturnType<typeof generate>) {
  const checks = [
    { k: "Handle SEO-safe", ok: /^[a-z0-9-]{3,60}$/.test(p.handle) },
    { k: "Title length ≤ 70", ok: p.titles[0].length <= 70 },
    { k: "Description 120–4096 chars", ok: p.description.length >= 120 && p.description.length <= 4096 },
    { k: "Tags ≤ 250 / each ≤ 255", ok: p.tags.length <= 250 && p.tags.every((t) => t.length <= 255) },
    { k: "SKU pattern", ok: /^RF-[A-Z]{1,3}-[A-Z0-9]{1,6}-\d{3}$/.test(p.sku) },
    { k: "Export wording present", ok: p.exportDesc.length > 40 },
  ];
  const pass = checks.filter((c) => c.ok).length;
  return { checks, pass, total: checks.length, ok: pass === checks.length };
}

function CatalogAI() {
  const queryClient = useQueryClient();
  const [inputs, setInputs] = useState<Inputs>({
    name: "",
    category: "Supplement",
    benefit: "energy, recovery and focus",
    audience: "ambitious professionals",
    priceNGN: "",
    weightKg: "0.50",
  });
  const [preview, setPreview] = useState<ReturnType<typeof generate> | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [published, setPublished] = useLocalStorage<{ handle: string; sku: string; name: string; at: number }[]>(
    "resoflex:published-products",
    [],
  );

  const ready = useMemo(() => inputs.name.trim().length > 1, [inputs]);
  const validation = useMemo(() => (preview ? validate(preview) : null), [preview]);

  const duplicate = useMemo(() => {
    if (!preview) return null;
    const dupHandle = published.find((p) => p.handle === preview.handle);
    const dupSku = published.find((p) => p.sku === preview.sku);
    if (dupHandle || dupSku) {
      return {
        handle: !!dupHandle,
        sku: !!dupSku,
        message: dupHandle && dupSku
          ? `Both handle "${preview.handle}" and SKU "${preview.sku}" already exist`
          : dupHandle
            ? `Handle "${preview.handle}" already exists`
            : `SKU "${preview.sku}" already exists`,
      };
    }
    return null;
  }, [preview, published]);

  const onGenerate = () => {
    if (!ready) {
      toast.error("Add a product name first");
      return;
    }
    setPreview(generate(inputs));
    setStage("draft");
    toast.success("ChatB2K draft generated");
  };

  const onApprove = () => {
    if (!preview || !validation?.ok) {
      toast.error("Fix validation issues before approving");
      return;
    }
    if (duplicate) {
      toast.error("Duplicate detected", { description: duplicate.message });
      return;
    }
    setStage("approved");
    toast.success("Draft approved — ready to publish");
  };

  const onPublish = async () => {
    if (!preview || stage !== "approved") {
      toast.error("Approve the draft first");
      return;
    }
    if (duplicate) {
      toast.error("Cannot publish duplicate", { description: duplicate.message });
      return;
    }
    setPublished([...published, { handle: preview.handle, sku: preview.sku, name: inputs.name, at: Date.now() }]);
    setStage("published");
    // Auto-sync: invalidate /shop query so storefront revalidates on next visit / mount
    await queryClient.invalidateQueries({ queryKey: ["shop"] });
    toast.message("Published to Shopify", {
      description: "Storefront auto-sync triggered. /shop will revalidate immediately.",
    });
  };


  return (
    <main className="min-h-screen pb-24">
      <Nav />

      <section className="mx-auto max-w-6xl px-5 pt-8">
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary/80">
          <Sparkles className="h-3.5 w-3.5" /> Admin · Catalog AI
        </div>
        <h1 className="mt-2 text-3xl font-bold md:text-4xl">
          ChatB2K <span className="text-gradient-gold">Commerce Console</span>
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Generate Shopify-ready titles, descriptions, SEO keywords, image prompts, SKUs and export metadata.
          Lightweight, client-side — no heavy media generated server-side.
        </p>
      </section>

      <section className="mx-auto mt-6 grid max-w-6xl gap-5 px-5 lg:grid-cols-[1fr_1.4fr]">
        {/* Inputs */}
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Package className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-bold uppercase tracking-wider">Product Basics</h2>
          </div>
          <div className="mt-4 space-y-3">
            <Field label="Product name">
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="e.g. Sovereign Hex Dumbbell 10kg"
                value={inputs.name}
                onChange={(e) => setInputs({ ...inputs, name: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Category">
                <input
                  className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  value={inputs.category}
                  onChange={(e) => setInputs({ ...inputs, category: e.target.value })}
                />
              </Field>
              <Field label="Price (NGN)">
                <input
                  className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  placeholder="25000"
                  value={inputs.priceNGN}
                  onChange={(e) => setInputs({ ...inputs, priceNGN: e.target.value })}
                />
              </Field>
            </div>
            <Field label="Primary benefit">
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                value={inputs.benefit}
                onChange={(e) => setInputs({ ...inputs, benefit: e.target.value })}
              />
            </Field>
            <Field label="Target audience">
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                value={inputs.audience}
                onChange={(e) => setInputs({ ...inputs, audience: e.target.value })}
              />
            </Field>
            <Field label="Net weight (kg)">
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                value={inputs.weightKg}
                onChange={(e) => setInputs({ ...inputs, weightKg: e.target.value })}
              />
            </Field>
            <button
              onClick={onGenerate}
              className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-gold transition-transform hover:scale-[1.01]"
            >
              <Brain className="h-4 w-4" /> Generate with ChatB2K
            </button>
            <p className="text-[11px] text-muted-foreground">
              Runs locally. No tokens consumed. Compliant with global e-commerce export standards.
            </p>
          </div>
        </div>

        {/* Preview */}
        <div className="space-y-4">
          {!preview && (
            <div className="glass flex h-full min-h-[300px] flex-col items-center justify-center rounded-2xl p-10 text-center">
              <ShieldCheck className="h-8 w-8 text-primary" />
              <h3 className="mt-3 text-sm font-bold">Awaiting generation</h3>
              <p className="mt-1 max-w-sm text-xs text-muted-foreground">
                Fill the basics and run ChatB2K. A Shopify-ready preview will appear with copy-to-clipboard on every field.
              </p>
            </div>
          )}

          {preview && (
            <>
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Tag className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-bold uppercase tracking-wider">Metadata</h3>
                  </div>
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Shopify-ready</span>
                </div>

                <div className="mt-4 space-y-3 text-sm">
                  <Block label="Title options">
                    <ul className="space-y-1">
                      {preview.titles.map((t) => (
                        <li key={t} className="flex items-center justify-between gap-2 rounded-md border border-border/40 bg-background/30 px-3 py-2">
                          <span className="truncate">{t}</span>
                          <button onClick={() => copy(t, "Title copied")} className="text-primary"><Copy className="h-3.5 w-3.5" /></button>
                        </li>
                      ))}
                    </ul>
                  </Block>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <KV k="Handle" v={preview.handle} />
                    <KV k="SKU" v={preview.sku} />
                    <KV k="GTIN placeholder" v={preview.gtin} />
                    <KV k="Price (NGN)" v={preview.priceNGN} />
                  </div>

                  <Block label="Description">
                    <div className="rounded-md border border-border/40 bg-background/30 p-3 text-xs leading-relaxed text-foreground/90">
                      {preview.description}
                    </div>
                    <CopyBtn text={preview.description} />
                  </Block>

                  <Block label="Export-ready description (customs-safe)">
                    <div className="rounded-md border border-border/40 bg-background/30 p-3 text-xs leading-relaxed text-foreground/90">
                      {preview.exportDesc}
                    </div>
                    <CopyBtn text={preview.exportDesc} />
                  </Block>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <Block label="SEO keywords">
                      <ChipList items={preview.keywords} />
                    </Block>
                    <Block label="Shopify tags">
                      <ChipList items={preview.tags} />
                    </Block>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <Block label="Collections">
                      <ChipList items={preview.collections} />
                    </Block>
                    <Block label="Upsell pairings">
                      <ChipList items={preview.upsells} />
                    </Block>
                  </div>

                  <Block label="Shipping metadata">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <KV k="Weight" v={`${preview.shipping.weightKg} kg`} />
                      <KV k="HS code" v={preview.shipping.hs} />
                      <KV k="Origin" v={preview.shipping.origin} />
                      <KV k="Customs note" v={preview.shipping.customsWording} />
                    </div>
                  </Block>
                </div>
              </div>

              {/* Image prompt engine */}
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-primary" />
                  <h3 className="text-sm font-bold uppercase tracking-wider">Image Prompt Engine</h3>
                </div>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Optimized prompts only — paste into any image model. No heavy media generated server-side.
                </p>
                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  {Object.entries(preview.imagePrompts).map(([k, v]) => (
                    <div key={k} className="rounded-md border border-border/40 bg-background/30 p-3">
                      <div className="text-[10px] uppercase tracking-widest text-primary">{k}</div>
                      <p className="mt-1 text-xs leading-relaxed text-foreground/90">{v}</p>
                      <CopyBtn text={v} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Validation + Draft pipeline */}
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                    <h3 className="text-sm font-bold uppercase tracking-wider">Shopify Validation</h3>
                  </div>
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    {validation?.pass}/{validation?.total} passing
                  </span>
                </div>
                <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                  {validation?.checks.map((c) => (
                    <li
                      key={c.k}
                      className={`flex items-center gap-2 rounded-md border px-3 py-2 text-xs ${
                        c.ok ? "border-primary/30 bg-primary/5 text-foreground" : "border-destructive/40 bg-destructive/5 text-foreground"
                      }`}
                    >
                      {c.ok ? <CheckCircle2 className="h-3.5 w-3.5 text-primary" /> : <AlertTriangle className="h-3.5 w-3.5 text-destructive" />}
                      {c.k}
                    </li>
                  ))}
                </ul>

                <div className="mt-4 flex items-center gap-2 text-[11px] text-muted-foreground">
                  <Pill active={stage === "draft" || stage === "approved" || stage === "published"}>Draft</Pill>
                  <span>→</span>
                  <Pill active={stage === "approved" || stage === "published"}>Approved</Pill>
                  <span>→</span>
                  <Pill active={stage === "published"}>Published</Pill>
                  <span>→</span>
                  <Pill active={stage === "published"}>/shop synced</Pill>
                </div>
              </div>

              {duplicate && (
                <div className="flex items-start gap-2 rounded-xl border border-destructive/50 bg-destructive/10 p-3 text-xs text-foreground">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                  <div>
                    <div className="font-semibold text-destructive">Duplicate detected — publish blocked</div>
                    <div className="mt-0.5 text-muted-foreground">{duplicate.message}. Change the product name to regenerate a unique handle &amp; SKU.</div>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => copy(JSON.stringify(preview, null, 2), "Full spec copied")}
                  className="inline-flex items-center gap-2 rounded-md border border-border bg-background/40 px-4 py-2.5 text-sm font-medium hover:bg-primary/10"
                >
                  <Copy className="h-4 w-4" /> Copy full JSON spec
                </button>
                <button
                  onClick={onApprove}
                  disabled={stage === "approved" || stage === "published" || !validation?.ok || !!duplicate}
                  className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-4 py-2.5 text-sm font-semibold text-foreground hover:bg-primary/20 disabled:opacity-50"
                >
                  <CheckCircle2 className="h-4 w-4" /> Approve draft
                </button>
                <button
                  onClick={onPublish}
                  disabled={stage !== "approved" || !!duplicate}
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-gold disabled:opacity-50"
                >
                  <Rocket className="h-4 w-4" /> Publish &amp; auto-sync /shop
                </button>
              </div>
            </>
          )}
        </div>
      </section>

      <Footer />
    </main>
  );
}

function Pill({ active, children }: { active: boolean; children: React.ReactNode }) {
  return (
    <span
      className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${
        active ? "border-primary/50 bg-primary/15 text-primary" : "border-border/60 bg-background/40 text-muted-foreground"
      }`}
    >
      {children}
    </span>
  );
}



function Block({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-1 text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      {children}
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-md border border-border/40 bg-background/30 px-3 py-2 text-xs">
      <span className="text-muted-foreground">{k}</span>
      <span className="truncate font-medium text-foreground">{v}</span>
    </div>
  );
}

function ChipList({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.map((it) => (
        <button
          key={it}
          onClick={() => copy(it, "Copied")}
          className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-1 text-[11px] text-foreground hover:bg-primary/20"
        >
          {it}
        </button>
      ))}
    </div>
  );
}

function CopyBtn({ text }: { text: string }) {
  return (
    <button
      onClick={() => copy(text)}
      className="mt-1 inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
    >
      <Copy className="h-3 w-3" /> Copy
    </button>
  );
}
