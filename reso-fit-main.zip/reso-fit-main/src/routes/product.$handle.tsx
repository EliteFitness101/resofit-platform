import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CartDrawer } from "@/components/CartDrawer";
import { useCartSync } from "@/hooks/useCartSync";
import { useCartStore } from "@/stores/cartStore";
import { PRODUCT_BY_HANDLE_QUERY, storefrontApiRequest } from "@/lib/shopify";

export const Route = createFileRoute("/product/$handle")({
  component: ProductPage,
});

function ProductPage() {
  useCartSync();
  const { handle } = useParams({ from: "/product/$handle" });
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);
  const [variantIdx, setVariantIdx] = useState(0);

  const { data, isLoading: loading } = useQuery({
    queryKey: ["product", handle],
    queryFn: async () => {
      const res = await storefrontApiRequest(PRODUCT_BY_HANDLE_QUERY, { handle });
      return res?.data?.productByHandle;
    },
  });

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4">
        <p className="text-muted-foreground">Product not found.</p>
        <Link to="/shop" className="text-sm underline">
          Back to shop
        </Link>
      </div>
    );
  }

  const variants = data.variants.edges.map((e: { node: unknown }) => e.node) as Array<{
    id: string;
    title: string;
    price: { amount: string; currencyCode: string };
    availableForSale: boolean;
    selectedOptions: Array<{ name: string; value: string }>;
  }>;
  const variant = variants[variantIdx];
  const images = data.images.edges.map((e: { node: { url: string; altText: string | null } }) => e.node);

  const handleAdd = async () => {
    if (!variant) return;
    await addItem({
      product: { node: data },
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
  };

  return (
    <main className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="container mx-auto flex items-center justify-between px-4 py-4">
          <Link to="/shop" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Shop
          </Link>
          <CartDrawer />
        </div>
      </header>

      <section className="container mx-auto grid gap-10 px-4 py-12 md:grid-cols-2">
        <div className="space-y-3">
          <div className="aspect-square overflow-hidden rounded-2xl bg-secondary/30">
            {images[0] && (
              <img src={images[0].url} alt={images[0].altText || data.title} className="h-full w-full object-cover" />
            )}
          </div>
          {images.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {images.slice(1, 5).map((img: { url: string; altText: string | null }, i: number) => (
                <img
                  key={i}
                  src={img.url}
                  alt={img.altText || ""}
                  className="aspect-square w-full rounded-lg object-cover"
                />
              ))}
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{data.title}</h1>
            <p className="mt-2 text-2xl font-semibold">
              {variant.price.currencyCode} {parseFloat(variant.price.amount).toFixed(2)}
            </p>
          </div>
          <p className="whitespace-pre-line text-muted-foreground">{data.description}</p>

          {variants.length > 1 && (
            <div className="space-y-2">
              <p className="text-sm font-medium">Variant</p>
              <div className="flex flex-wrap gap-2">
                {variants.map((v, i) => (
                  <button
                    key={v.id}
                    onClick={() => setVariantIdx(i)}
                    className={`rounded-md border px-3 py-1.5 text-sm transition-colors ${
                      i === variantIdx ? "border-primary bg-primary/10" : "hover:bg-accent"
                    }`}
                  >
                    {v.title}
                  </button>
                ))}
              </div>
            </div>
          )}

          <Button onClick={handleAdd} disabled={!variant?.availableForSale || isLoading} size="lg" className="w-full">
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : variant?.availableForSale ? (
              "Add to Cart"
            ) : (
              "Sold out"
            )}
          </Button>
        </div>
      </section>
    </main>
  );
}
