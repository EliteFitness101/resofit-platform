import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { Megaphone, Sparkles, Copy, TrendingUp, Target, Zap, Link2 } from "lucide-react";
import { toast } from "sonner";
import { useLocalStorage } from "@/hooks/useLocalStorage";

export const Route = createFileRoute("/admin/ads-intel")({
  head: () => ({
    meta: [
      { title: "Ads Intelligence — ROAS Creative Engine | ResoFlex OS" },
      { name: "description", content: "Generate channel-specific ad creatives, ROAS optimization hooks and post-paid pre-optimized campaign exports for Meta, TikTok, WhatsApp & Email." },
      { property: "og:title", content: "Ads Intelligence — ResoFlex Commerce OS" },
      { property: "og:description", content: "AI creative engine generating pre-optimized ad assets across channels." },
    ],
  }),
  component: AdsIntel,
});

type Creative = {
  channel: string;
  hook: string;
  body: string;
  cta: string;
  roasHint: string;
};

function copy(t: string) {
  navigator.clipboard.writeText(t).then(() => toast.success("Copied"));
}

function generate(product: string, audience: string, offer: string): Creative[] {
  const p = product || "ResoFlex Reset";
  const a = audience || "Lagos women 25–40";
  const o = offer || "30-day glow protocol";
  return [
    {
      channel: "Meta Reels",
      hook: `Stop scrolling — ${a} are obsessed with ${p}`,
      body: `${o}. Real testimonials, no filters. Limited restock this week.`,
      cta: "Shop now →",
      roasHint: "Target lookalike of past Paystack buyers. Expected ROAS 3.2–4.1x.",
    },
    {
      channel: "TikTok Spark Ads",
      hook: `POV: ${a} discover the ${p} unlock`,
      body: `7 days in, the glow speaks. Comment GLOW for the drop link.`,
      cta: "Tap to claim",
      roasHint: "Boost organic clips scoring ≥0.85. Expected CPM −22% vs static.",
    },
    {
      channel: "WhatsApp Broadcast",
      hook: `${p} restock alert 🚨`,
      body: `${o} — VIP cohort price for 48hrs. Reply YES to lock in.`,
      cta: "Reply YES",
      roasHint: "Warm cohort: 18–24% conversion. Pair with referral ₦5k bonus.",
    },
    {
      channel: "Email Flow",
      hook: `Your ${p} window closes Sunday`,
      body: `${a} who started this week report measurable shifts by day 9. ${o}.`,
      cta: "Secure your kit",
      roasHint: "Cart-abandon segment. Expected RPM lift +31%.",
    },
  ];
}

function AdsIntel() {
  const [product, setProduct] = useState("ResoFlex Reset");
  const [audience, setAudience] = useState("Lagos women 25–40");
  const [offer, setOffer] = useState("30-day glow protocol");
  const [out, setOut] = useLocalStorage<Creative[] | null>("resoflex:ads-out", null);
  const [postPaid, setPostPaid] = useLocalStorage<boolean>("resoflex:ads-postpaid", false);
  const [accountId, setAccountId] = useLocalStorage<string>("resoflex:ads-account-id", "");
  const [accountConnected, setAccountConnected] = useLocalStorage<boolean>("resoflex:ads-account-connected", false);

  const summary = useMemo(() => {
    if (!out) return null;
    return { count: out.length, channels: out.map((c) => c.channel).join(" · ") };
  }, [out]);

  const exportJson = () => {
    if (!out) return;
    const payload = {
      account: { id: accountId || null, connected: accountConnected },
      brief: { product, audience, offer },
      creatives: out,
      ...(postPaid && { billing_status: "post-paid", optimization: "PRE-OPTIMIZED" }),
      generated_at: new Date().toISOString(),
    };
    copy(JSON.stringify(payload, null, 2));
    toast.success("Export copied", { description: postPaid ? "Includes post-paid pre-optimization flags" : undefined });
  };

  return (
    <main className="min-h-screen pb-24">
      <Nav />
      <section className="mx-auto max-w-6xl px-5 pt-8">
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary/80">
          <Megaphone className="h-3.5 w-3.5" /> Admin · Ads Intelligence
        </div>
        <h1 className="mt-2 text-3xl font-bold md:text-4xl">
          ROAS <span className="text-gradient-gold">Creative Engine</span>
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Generate channel-specific ad creatives, captions and ROAS optimization hooks. Pairs with Replay Intelligence clips.
        </p>
      </section>

      <section className="mx-auto mt-6 grid max-w-6xl gap-5 px-5 lg:grid-cols-[1fr_1.4fr]">
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Target className="h-4 w-4 text-primary" />
            <h2 className="text-sm font-bold uppercase tracking-wider">Campaign Brief</h2>
          </div>
          <div className="mt-4 space-y-3">
            {[
              { k: "Product", v: product, set: setProduct },
              { k: "Audience", v: audience, set: setAudience },
              { k: "Offer", v: offer, set: setOffer },
            ].map((f) => (
              <label key={f.k} className="block">
                <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">{f.k}</span>
                <input
                  className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  value={f.v}
                  onChange={(e) => f.set(e.target.value)}
                />
              </label>
            ))}
            <button
              onClick={() => { setOut(generate(product, audience, offer)); toast.success("Creatives generated"); }}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-gold"
            >
              <Sparkles className="h-4 w-4" /> Generate ad creatives
            </button>
          </div>

          {/* Ad Account Sync */}
          <div className="mt-5 border-t border-border/40 pt-5">
            <div className="flex items-center gap-2">
              <Link2 className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-bold uppercase tracking-wider">Ad Account Sync</h3>
            </div>
            <label className="mt-3 block">
              <span className="mb-1 block text-[11px] uppercase tracking-wider text-muted-foreground">Account ID</span>
              <input
                className="h-10 w-full rounded-md border border-border bg-background/40 px-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="act_123456789"
                value={accountId}
                onChange={(e) => setAccountId(e.target.value)}
              />
            </label>
            <button
              onClick={() => { setAccountConnected(!accountConnected); toast.success(accountConnected ? "Account disconnected" : "Account connected"); }}
              className={`mt-3 inline-flex w-full items-center justify-center gap-2 rounded-md border px-4 py-2.5 text-xs font-semibold transition ${accountConnected ? "border-primary/50 bg-primary/15 text-primary" : "border-border bg-background/40 hover:bg-primary/10"}`}
            >
              <Link2 className="h-3.5 w-3.5" /> {accountConnected ? "Connected" : "Connect ad account"}
            </button>

            <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-lg border border-border/50 bg-background/30 p-3">
              <input
                type="checkbox"
                className="mt-0.5 h-4 w-4 accent-primary"
                checked={postPaid}
                onChange={(e) => setPostPaid(e.target.checked)}
              />
              <span className="flex-1">
                <span className="flex items-center gap-1.5 text-xs font-semibold">
                  <Zap className="h-3 w-3 text-primary" /> Post-Paid Pre-Optimization
                </span>
                <span className="mt-0.5 block text-[11px] text-muted-foreground">
                  Injects <code className="font-mono text-primary">billing_status: "post-paid"</code> and <code className="font-mono text-primary">optimization: "PRE-OPTIMIZED"</code> into the JSON export.
                </span>
              </span>
            </label>
          </div>
        </div>

        <div className="space-y-4">
          {!out && (
            <div className="glass flex h-full min-h-[300px] flex-col items-center justify-center rounded-2xl p-10 text-center">
              <Megaphone className="h-8 w-8 text-primary" />
              <h3 className="mt-3 text-sm font-bold">Awaiting brief</h3>
              <p className="mt-1 max-w-sm text-xs text-muted-foreground">
                Fill the brief and generate channel-ready creatives with ROAS hints.
              </p>
            </div>
          )}
          {out && summary && (
            <>
              <div className="glass rounded-xl p-4 text-xs text-muted-foreground">
                <TrendingUp className="mr-1 inline h-3.5 w-3.5 text-primary" />
                {summary.count} creatives across {summary.channels}
              </div>
              {out.map((c) => (
                <div key={c.channel} className="glass rounded-2xl p-5">
                  <div className="flex items-center justify-between">
                    <div className="text-[10px] uppercase tracking-widest text-primary">{c.channel}</div>
                    <button onClick={() => copy(`${c.hook}\n\n${c.body}\n\n${c.cta}`)} className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline">
                      <Copy className="h-3 w-3" /> Copy
                    </button>
                  </div>
                  <h3 className="mt-1 text-base font-bold">{c.hook}</h3>
                  <p className="mt-1 text-sm text-foreground/90">{c.body}</p>
                  <div className="mt-2 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-[11px] text-foreground">
                    CTA · {c.cta}
                  </div>
                  <p className="mt-3 text-[11px] text-muted-foreground">ROAS hint: {c.roasHint}</p>
                </div>
              ))}
              <button
                onClick={exportJson}
                className="inline-flex items-center gap-2 rounded-md border border-primary/40 bg-primary/10 px-4 py-2.5 text-sm font-semibold hover:bg-primary/20"
              >
                <Copy className="h-3.5 w-3.5" /> Export campaign JSON{postPaid ? " (post-paid)" : ""}
              </button>
            </>
          )}
        </div>
      </section>
      <Footer />
    </main>
  );
}
