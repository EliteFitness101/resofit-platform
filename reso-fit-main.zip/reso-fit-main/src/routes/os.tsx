import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Nav } from "@/components/Nav";
import { Footer } from "@/components/Footer";
import { ECOSYSTEM } from "@/services/router";
import { Activity, Brain, Compass, Coins, Crown, Flame, LineChart, Rocket, ShieldCheck, Sparkles, Users } from "lucide-react";
import { CommerceDashboard } from "@/components/CommerceDashboard";

export const Route = createFileRoute("/os")({
  head: () => ({
    meta: [
      { title: "Sovereign Gateway OS — ResoFlex Commerce & Wellness Intelligence" },
      { name: "description", content: "AI-powered wellness, commerce and capital intelligence dashboard coordinating the ResoFlex ecosystem in real time." },
      { property: "og:title", content: "ResoFlex Sovereign Gateway OS" },
      { property: "og:description", content: "Centralized intelligence layer for the ResoFit ecosystem — trending SKUs, ROAS, referral performance." },
    ],
  }),
  component: GatewayOS,
});

type Node = {
  label: string;
  desc: string;
  href: string;
  zone: "Funnel" | "Train" | "Commerce" | "Creator" | "Capital";
  health: number; // 0-100 telemetric stub
  icon: React.ComponentType<{ className?: string }>;
};

const NODES: Node[] = [
  { label: "Joy Funnel", desc: "Primary checkout funnel", href: ECOSYSTEM.checkout, zone: "Funnel", health: 96, icon: Flame },
  { label: "ResoFit Evolution", desc: "Returning user funnel", href: ECOSYSTEM.evolution, zone: "Funnel", health: 88, icon: Rocket },
  { label: "NowNow Gym", desc: "Home + outdoor workouts", href: ECOSYSTEM.nownowgym, zone: "Train", health: 91, icon: Activity },
  { label: "ResoGold", desc: "Elite training OS", href: ECOSYSTEM.resogold, zone: "Train", health: 84, icon: Crown },
  { label: "Sovereign Gold Flow", desc: "Premium movement", href: ECOSYSTEM.goldFlow, zone: "Train", health: 79, icon: Sparkles },
  { label: "Elite Products", desc: "VIP supplement vault", href: ECOSYSTEM.elite, zone: "Commerce", health: 93, icon: ShieldCheck },
  { label: "Naija Elite Store", desc: "Marketplace", href: ECOSYSTEM.naijaStore, zone: "Commerce", health: 87, icon: Coins },
  { label: "ResoFlex Reset", desc: "Flagship supplement", href: ECOSYSTEM.supplement, zone: "Commerce", health: 95, icon: ShieldCheck },
  { label: "Sovereign Vault", desc: "Members-only intel", href: ECOSYSTEM.vault, zone: "Creator", health: 82, icon: Brain },
  { label: "Candera Auth", desc: "Identity & session", href: ECOSYSTEM.auth, zone: "Capital", health: 99, icon: ShieldCheck },
];

const ZONES: Node["zone"][] = ["Funnel", "Train", "Commerce", "Creator", "Capital"];

const SIGNALS = [
  { label: "Conversion Pulse", value: "↑ 18.4%", hint: "Joy Funnel last 24h", icon: LineChart },
  { label: "Engagement Index", value: "7.2 / 10", hint: "ChatB2K weighted", icon: Brain },
  { label: "Referral Velocity", value: "+₦142k", hint: "Pending payout", icon: Users },
  { label: "Ecosystem Uptime", value: "99.6%", hint: "All nodes healthy", icon: Activity },
];

const AI_HOOKS = [
  "Push WhatsApp drip to 'Engage' cohort — 24% predicted conversion lift.",
  "Bundle ResoFlex Reset + NowNow Gym for returning users — high LTV signal.",
  "Spin a creator clip from top-performing testimonial — viral score 0.81.",
  "Investor brief: wellness commerce TAM up 11% QoQ in Lagos corridor.",
];

function GatewayOS() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => (t + 1) % 1000), 2500);
    return () => clearInterval(id);
  }, []);

  return (
    <main className="min-h-screen pb-24">
      <Nav />

      <section className="mx-auto max-w-6xl px-5 pt-8">
        <div className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-primary/80">
          <Compass className="h-3.5 w-3.5" /> Sovereign Gateway OS
        </div>
        <h1 className="mt-2 text-3xl font-bold md:text-4xl">
          Ecosystem <span className="text-gradient-gold">Intelligence</span>
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Centralized AI routing, commerce telemetry and milestone analytics across every ResoFlex node.
          External apps stay modular — this layer coordinates intent, conversion and capital flow.
        </p>
      </section>

      {/* Telemetry */}
      <section className="mx-auto mt-6 grid max-w-6xl grid-cols-2 gap-3 px-5 md:grid-cols-4">
        {SIGNALS.map((s) => (
          <div key={s.label} className="glass rounded-xl p-4">
            <div className="flex items-center justify-between text-xs uppercase tracking-wider text-muted-foreground">
              <span>{s.label}</span>
              <s.icon className="h-3.5 w-3.5 text-primary" />
            </div>
            <div className="mt-2 text-xl font-bold text-foreground">{s.value}</div>
            <div className="mt-1 text-[11px] text-muted-foreground">{s.hint}</div>
          </div>
        ))}
      </section>

      {/* Ecosystem map */}
      <section className="mx-auto mt-10 max-w-6xl px-5">
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-lg font-bold">Ecosystem Map</h2>
          <span className="text-[11px] text-muted-foreground">Live · tick {tick.toString().padStart(3, "0")}</span>
        </div>
        <div className="space-y-5">
          {ZONES.map((zone) => {
            const items = NODES.filter((n) => n.zone === zone);
            if (!items.length) return null;
            return (
              <div key={zone}>
                <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-primary/70">{zone}</div>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map((n) => (
                    <a
                      key={n.label}
                      href={n.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="glass group block rounded-xl p-4 transition-transform hover:-translate-y-0.5 hover:shadow-gold"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/15 text-primary">
                            <n.icon className="h-4 w-4" />
                          </span>
                          <div>
                            <div className="text-sm font-semibold group-hover:text-primary">{n.label}</div>
                            <div className="text-[11px] text-muted-foreground">{n.desc}</div>
                          </div>
                        </div>
                        <span className="text-[10px] text-primary opacity-0 transition-opacity group-hover:opacity-100">↗</span>
                      </div>
                      <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-border/40">
                        <div
                          className="h-full"
                          style={{ width: `${n.health}%`, background: "var(--gradient-gold)" }}
                        />
                      </div>
                      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
                        <span>health</span>
                        <span>{n.health}%</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* AI intelligence */}
      <section className="mx-auto mt-10 max-w-6xl px-5">
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2">
            <Brain className="h-4 w-4 text-primary" />
            <h2 className="text-lg font-bold">ChatB2K — Strategic Intelligence</h2>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Predictive hooks generated from ecosystem telemetry. Recommendations only — no autonomous spend.
          </p>
          <ul className="mt-4 space-y-2">
            {AI_HOOKS.map((h) => (
              <li key={h} className="flex items-start gap-2 rounded-lg border border-border/40 bg-background/30 p-3 text-sm">
                <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                <span className="text-foreground/90">{h}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Referral + creator + investor strip */}
      <section className="mx-auto mt-8 grid max-w-6xl gap-3 px-5 md:grid-cols-3">
        <a href={ECOSYSTEM.auth} className="glass rounded-xl p-5 transition-transform hover:-translate-y-0.5">
          <Users className="h-5 w-5 text-primary" />
          <h3 className="mt-2 text-sm font-bold">Referral Progress</h3>
          <p className="mt-1 text-xs text-muted-foreground">Earn ₦5,000 per paid referral. Auto-credited via Paystack webhook.</p>
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-border/40">
            <div className="h-full w-[42%]" style={{ background: "var(--gradient-gold)" }} />
          </div>
          <div className="mt-1 text-[10px] text-muted-foreground">3 of 7 to next tier</div>
        </a>
        <a href={ECOSYSTEM.vault} target="_blank" rel="noopener noreferrer" className="glass rounded-xl p-5 transition-transform hover:-translate-y-0.5">
          <Crown className="h-5 w-5 text-primary" />
          <h3 className="mt-2 text-sm font-bold">Creator Economy</h3>
          <p className="mt-1 text-xs text-muted-foreground">Drop content into the Sovereign Vault, earn from every conversion.</p>
        </a>
        <a href="mailto:invest@resoflex.name.ng" className="glass rounded-xl p-5 transition-transform hover:-translate-y-0.5">
          <Coins className="h-5 w-5 text-primary" />
          <h3 className="mt-2 text-sm font-bold">Investor Positioning</h3>
          <p className="mt-1 text-xs text-muted-foreground">Wellness × commerce × AI infrastructure. Brief on request.</p>
        </a>
      </section>


      {/* Commerce Intelligence Dashboard */}
      <section className="mx-auto mt-10 max-w-6xl px-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Coins className="h-4 w-4 text-primary" />
            <h2 className="text-lg font-bold">Commerce Intelligence Dashboard</h2>
          </div>
          <a href="/admin/catalog-ai" className="text-[11px] text-primary hover:underline">Open Catalog AI →</a>
        </div>
        <CommerceDashboard />
      </section>

      <Footer />
    </main>
  );
}
