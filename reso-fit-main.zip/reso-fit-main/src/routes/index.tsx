import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { StickyCTA } from "@/components/StickyCTA";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import { PremiumBubbles } from "@/components/PremiumBubbles";
import { Footer } from "@/components/Footer";
import { Countdown } from "@/components/Countdown";
import { SocialProof } from "@/components/SocialProof";
import { Testimonials } from "@/components/Testimonials";
import { FAQ } from "@/components/FAQ";
import { BMICalculator } from "@/components/BMICalculator";
import { ExitIntent } from "@/components/ExitIntent";
import { ECOSYSTEM } from "@/services/router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ResoFit — Sovereign AI Body OS for Nigerians" },
      { name: "description", content: "Transform your body with the AI-powered fitness, nutrition and supplement OS built for Nigerians. Secure Paystack checkout. Instant access." },
      { property: "og:title", content: "ResoFit — Sovereign AI Body OS" },
      { property: "og:description", content: "AI-powered fitness, nutrition and supplements built for Nigerians. One system. One transformation." },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <main className="min-h-screen pb-24 md:pb-0">
      <Nav />
      <Hero />
      <div className="px-5"><SocialProof /></div>
      <div className="mt-8 px-5"><Countdown /></div>
      <Testimonials />
      <BMICalculator />
      <FAQ />

      <section className="mx-auto max-w-3xl px-5 py-12">
        <div className="glass rounded-2xl p-6 text-center">
          <h3 className="text-lg font-bold">Refer a friend. Earn ₦5,000.</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Every paid referral credits your dashboard automatically via Paystack webhook.
          </p>
          <a href={ECOSYSTEM.auth} className="mt-4 inline-block text-sm font-semibold text-primary underline">
            Set up your referral code →
          </a>
        </div>
      </section>

      <Footer />

      <StickyCTA />
      <WhatsAppFloat />
      <PremiumBubbles />
      <ExitIntent />
    </main>
  );
}
