## Scope

This project = **resofit.fit entry hub only**. Frontend-only. No backend, no Paystack code, no DB. All payments, dashboards, and unlocks stay in the existing Lovable projects (joy-funnel-ai, reso-flex-pwa, etc.). This project routes users *to* them.

## What gets built

A single-page mobile-first landing on `/` plus a few supporting routes, with a smart router that decides where to send the user based on local signals.

### Routes (TanStack Start, file-based in `src/routes/`)
- `index.tsx` — landing funnel (hero + conversion stack)
- `go.tsx` — router endpoint: reads `?intent=…` and `localStorage` flags, redirects to the right ecosystem URL
- `success.tsx` — post-Paystack landing (joy-funnel-ai redirects here with a signed token in the query string); validates token shape and forwards to `reso-flex-pwa.lovable.app/macros`

### Smart router logic (`src/services/router.ts`)
Pure client-side decision tree, no backend:
- `paid` flag in localStorage → `reso-flex-pwa.lovable.app/macros`
- `returning` flag → `resofit-evolution.lovable.app`
- `intent=checkout` query or high-intent CTA click → `joy-funnel-ai.lovable.app`
- `intent=vip` → `elite-products.lovable.app`
- default (new visitor) → stay on landing

Token from `/success?token=…` is validated by shape only (signature verification belongs in joy-funnel-ai). On valid token: set `paid=true` in localStorage, then redirect.

### Conversion components (`src/components/`)
All lightweight, no extra deps beyond what shadcn already provides:
- `Hero.tsx` — headline + primary CTA → `/go?intent=checkout`
- `StickyCTA.tsx` — sticky bottom bar (mobile-first)
- `WhatsAppFloat.tsx` — floating WA button (pure anchor, no SDK)
- `Countdown.tsx` — simple 24h rolling countdown
- `SocialProof.tsx` — "X users joined today" (seeded pseudo-random by date)
- `Testimonials.tsx` — Nigeria-focused, horizontal scroll-snap (no carousel lib)
- `FAQ.tsx` — uses existing shadcn `accordion`
- `BMICalculator.tsx` — local-only form
- `ExitIntent.tsx` — `mouseleave` listener, single dismiss per session

### Design system (`src/styles.css`)
Update tokens only — no new component lib:
- `--background: #070708`, surface `#121212`
- `--primary` (gold): `#E0A96D`
- `--foreground`: `#F5F1EA`
- Glassmorphism utility class (backdrop-blur + translucent border)
- Dark mode is the default and only mode

### What is intentionally NOT built here
- No Paystack SDK, no webhook receiver, no Cloud
- No real auth — only a localStorage "paid" flag set after `/success` token validation
- No Treasury/AI/ROAS dashboard (would need backend; user declined Cloud)
- No checkout UI (lives in joy-funnel-ai)
- No `/macros` dashboard (lives in reso-flex-pwa)

## Technical notes

- Stack stays as-is: TanStack Start + Tailwind + shadcn. No new deps.
- Each route file gets its own `head()` with route-specific title/description/og tags. `og:image` only on leaf routes.
- Outbound links use plain `<a href>` with `rel="noopener"` — these are cross-origin, not internal `<Link>`s.
- Token validation in `/success` is shape-only (length + base64url charset). Real verification is joy-funnel-ai's job; this project must not pretend to be the source of truth.
- All animations CSS-only (no Framer Motion).

## Out of scope / follow-ups (separate projects)
- Webhook truth system → already lives in joy-funnel-ai
- Treasury/GDP/ROAS dashboard → would need its own Lovable project with Cloud
- Cross-app shared auth → needs coordinated changes in joy-funnel-ai + reso-flex-pwa to issue/verify signed tokens (HMAC with shared secret). This plan assumes joy-funnel-ai already does the signing; if it doesn't, that's a separate task in *that* project.
